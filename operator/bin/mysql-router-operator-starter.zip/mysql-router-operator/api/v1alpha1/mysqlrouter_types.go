package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// SecretKeyRef identifies one key inside one Secret.
type SecretKeyRef struct {
	Name string `json:"name"`
	Key  string `json:"key"`
}

// ExternalNode describes one MySQL node outside Kubernetes.
type ExternalNode struct {
	Name    string `json:"name"`
	Address string `json:"address"`
	Port    int32  `json:"port"`
}

// BootstrapSpec controls how Router bootstraps against the external cluster.
type BootstrapSpec struct {
	// NodeName chooses which external node Service to use for bootstrap.
	// If empty, the controller uses the first item from externalNodes.
	NodeName string `json:"nodeName,omitempty"`

	UsernameSecretRef SecretKeyRef `json:"usernameSecretRef"`
	PasswordSecretRef SecretKeyRef `json:"passwordSecretRef"`

	// ExtraArgs appends extra command-line flags to mysqlrouter --bootstrap.
	// Avoid flags that trigger additional interactive password prompts.
	ExtraArgs []string `json:"extraArgs,omitempty"`
}

// RoutingSpec controls the generated Router listener configuration.
type RoutingSpec struct {
	// BindAddress is passed to mysqlrouter --conf-bind-address.
	// Default: 0.0.0.0
	BindAddress string `json:"bindAddress,omitempty"`

	// BasePort is passed to mysqlrouter --conf-base-port.
	// Router then uses basePort, basePort+1, basePort+2, basePort+3.
	// Default: 6446
	BasePort int32 `json:"basePort,omitempty"`

	// ExposeXProtocol controls whether the Service publishes the X ports.
	// Router still bootstraps the standard four routes.
	ExposeXProtocol bool `json:"exposeXProtocol,omitempty"`
}

// StorageSpec defines where mysqlrouter.conf and dynamic state are kept.
type StorageSpec struct {
	// Type is one of: EmptyDir, PersistentVolumeClaim
	// Default: EmptyDir
	Type string `json:"type,omitempty"`

	// ClaimName is required when Type == PersistentVolumeClaim.
	ClaimName string `json:"claimName,omitempty"`
}

// MySQLRouterSpec defines the desired state of MySQLRouter.
type MySQLRouterSpec struct {
	Image              string            `json:"image,omitempty"`
	ImagePullPolicy    string            `json:"imagePullPolicy,omitempty"`
	Replicas           *int32            `json:"replicas,omitempty"`
	ServiceType        string            `json:"serviceType,omitempty"`
	ServiceAnnotations map[string]string `json:"serviceAnnotations,omitempty"`

	Bootstrap BootstrapSpec `json:"bootstrap"`
	Routing   RoutingSpec   `json:"routing,omitempty"`
	Storage   StorageSpec   `json:"storage,omitempty"`

	ExternalNodes []ExternalNode `json:"externalNodes"`
}

// MySQLRouterStatus defines the observed state of MySQLRouter.
type MySQLRouterStatus struct {
	ObservedGeneration int64              `json:"observedGeneration,omitempty"`
	Phase              string             `json:"phase,omitempty"`
	ReadyReplicas      int32              `json:"readyReplicas,omitempty"`
	DeploymentName     string             `json:"deploymentName,omitempty"`
	ServiceName        string             `json:"serviceName,omitempty"`
	NodeServiceNames   []string           `json:"nodeServiceNames,omitempty"`
	EndpointSliceNames []string           `json:"endpointSliceNames,omitempty"`
	Conditions         []metav1.Condition `json:"conditions,omitempty"`
}

// +kubebuilder:object:root=true
// +kubebuilder:subresource:status
// +kubebuilder:resource:scope=Namespaced,shortName=myr
// +kubebuilder:printcolumn:name="Phase",type=string,JSONPath=`.status.phase`
// +kubebuilder:printcolumn:name="Ready",type=integer,JSONPath=`.status.readyReplicas`
// +kubebuilder:printcolumn:name="Service",type=string,JSONPath=`.status.serviceName`
// +kubebuilder:printcolumn:name="Age",type=date,JSONPath=`.metadata.creationTimestamp`

type MySQLRouter struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   MySQLRouterSpec   `json:"spec,omitempty"`
	Status MySQLRouterStatus `json:"status,omitempty"`
}

// +kubebuilder:object:root=true

type MySQLRouterList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []MySQLRouter `json:"items"`
}

func (in *MySQLRouter) Default() {
	if in.Spec.Image == "" {
		in.Spec.Image = "container-registry.oracle.com/mysql/community-router:8.4"
	}
	if in.Spec.ImagePullPolicy == "" {
		in.Spec.ImagePullPolicy = "IfNotPresent"
	}
	if in.Spec.Replicas == nil {
		var one int32 = 1
		in.Spec.Replicas = &one
	}
	if in.Spec.ServiceType == "" {
		in.Spec.ServiceType = "ClusterIP"
	}
	if in.Spec.Routing.BindAddress == "" {
		in.Spec.Routing.BindAddress = "0.0.0.0"
	}
	if in.Spec.Routing.BasePort == 0 {
		in.Spec.Routing.BasePort = 6446
	}
	if in.Spec.Storage.Type == "" {
		in.Spec.Storage.Type = "EmptyDir"
	}
}
