module github.com/example/mysql-router-operator

go 1.23.0

require sigs.k8s.io/controller-runtime v0.23.3
