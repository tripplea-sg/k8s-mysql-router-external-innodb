# MySQL Router Operator (starter)

This repository contains a **starter operator** for a custom Kubernetes resource named `MySQLRouter`.

It is designed for this topology:

- Kubernetes runs the application and the operator
- MySQL Router runs in Kubernetes
- The MySQL InnoDB Cluster nodes run **outside Kubernetes** on VMs or bare metal

## What the controller reconciles

For each `MySQLRouter` custom resource, the controller creates and maintains:

- one selector-less `Service` per external MySQL node
- one manually managed `EndpointSlice` per external MySQL node
- one `Deployment` running MySQL Router
- one fronting `Service` for application traffic to Router
- `status` conditions on the `MySQLRouter` resource

## API shape

```yaml
apiVersion: router.example.com/v1alpha1
kind: MySQLRouter
metadata:
  name: mysql-router
  namespace: mysql-router
spec:
  image: container-registry.oracle.com/mysql/community-router:8.4
  replicas: 1
  serviceType: ClusterIP
  bootstrap:
    nodeName: node-0
    usernameSecretRef:
      name: mysql-router-bootstrap
      key: username
    passwordSecretRef:
      name: mysql-router-bootstrap
      key: password
    extraArgs:
      - --ssl-mode=REQUIRED
  routing:
    bindAddress: 0.0.0.0
    basePort: 6446
    exposeXProtocol: true
  storage:
    type: PersistentVolumeClaim
    claimName: mysql-router-pvc
  externalNodes:
    - name: node-0
      address: 10.10.1.11
      port: 3306
    - name: node-1
      address: 10.10.1.12
      port: 3306
    - name: node-2
      address: 10.10.1.13
      port: 3306
```

## Important behavior

- The controller uses **EndpointSlice**, not legacy `Endpoints`.
- External node addresses must be **IP addresses**, not hostnames.
- The operator uses MySQL Router bootstrap with:
  - `--bootstrap`
  - `--directory /router`
  - `--conf-base-port`
  - `--conf-bind-address`
- `routing.basePort` controls the standard Router port sequence:
  - `basePort` = classic RW
  - `basePort + 1` = classic RO
  - `basePort + 2` = X RW
  - `basePort + 3` = X RO
- `routing.exposeXProtocol` only controls whether the Kubernetes Service publishes the X ports.
- Storage is either `EmptyDir` or an existing PVC.

## Project layout

```text
.
├── api/v1alpha1/
├── internal/controller/
├── config/crd/bases/
├── config/rbac/
├── config/manager/
├── config/samples/
├── dist/install.yaml
├── go.mod
├── main.go
└── README.md
```

## Deploying the operator

1. Build and push the controller image.
2. Replace the image in `config/manager/manager.yaml`.
3. Apply the operator bundle:

```bash
kubectl apply -f dist/install.yaml
```

4. Create the application namespace and PVC for Router state:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: mysql-router
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mysql-router-pvc
  namespace: mysql-router
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
```

5. Create the bootstrap secret:

```bash
kubectl apply -f config/samples/bootstrap-secret.yaml
```

6. Create the `MySQLRouter` custom resource:

```bash
kubectl apply -f config/samples/router_v1alpha1_mysqlrouter.yaml
```

## Operational notes

- Use a bootstrap account that can run Router bootstrap non-interactively.
- Avoid bootstrap flags that trigger additional password prompts unless you extend the controller command logic.
- If you want TLS, keep using `bootstrap.extraArgs`, for example `--ssl-mode=REQUIRED`.
- If you need fully arbitrary port assignment beyond the standard base-port sequence, extend the controller to post-process `mysqlrouter.conf` after bootstrap.

## Rename the API group before production

This starter uses `router.example.com` to avoid implying an official vendor API group.
Before production, rename it to your organization’s real API group in:

- `api/v1alpha1/groupversion_info.go`
- `config/crd/bases/router.example.com_mysqlrouters.yaml`
- `config/samples/router_v1alpha1_mysqlrouter.yaml`
- any manifests or generated client code
